#ifndef __EASYLZMA_LZMA_HEADER__
#define __EASYLZMA_LZMA_HEADER__

#include <lzma/api/common_internal.h>

/* LZMA-Alone header format gleaned from reading Igor's code */

void initializeLZMAFormatHandler(struct elzma_format_handler *hand);

#endif
